<?php

namespace App\Models\Kru;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\UuidKey;
use Illuminate\Database\Eloquent\SoftDeletes;
use Kyslik\ColumnSortable\Sortable;

class ImmigrationOffice extends Model
{
    use HasFactory, UuidKey, SoftDeletes, Sortable;
	  /**
     * The "type" of the primary key ID.
     *
     * @var string
     */
    protected $keyType = 'string';

    /**
     * Indicates if the IDs are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
    ];

    /**
     * The model's default values for attributes.
     *
     * @var array
     */
    protected $attributes = [
    ];

    /**
     * The sortable attributes.
     *
     * @var array
     */
    public $sortable = [
        'name',
    ];

	public static function seed($name)
    {
            $immigration_office = new ImmigrationOffice();
            $immigration_office->name = $name;
            $immigration_office->created_by = \App\Models\User::getAdminUser()->id;
            $immigration_office->updated_by = \App\Models\User::getAdminUser()->id;
            $immigration_office->save();
    }
}